library(shiny)
ui <- fluidPage()
  # *Input() functions,
  # *Output() functions

server <- function(input, output) {}

shinyApp(ui = ui, server = server)