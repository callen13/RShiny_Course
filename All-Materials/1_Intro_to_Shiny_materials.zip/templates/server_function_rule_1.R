server <- function(input, output) {
  output$hist <- # some code
    
}