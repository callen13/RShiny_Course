server <- function(input, output) {
  output$hist <- renderPlot({
    
  })
}