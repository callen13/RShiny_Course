library(shiny)
ui <- fluidPage("Hello Billy")

server <- function(input, output) {}

shinyApp(ui = ui, server = server)