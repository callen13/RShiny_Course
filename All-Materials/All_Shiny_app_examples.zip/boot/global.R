## Interactive PLS Path Modeling Online application server.R

# load needed libraries:
library("semPLS")
library("plspm")
library("XML")
library("shiny")
library("lattice")


