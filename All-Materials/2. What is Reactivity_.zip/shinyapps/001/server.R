## 001 ~/shinyapps Live Example server.R

library(shiny)

# Define server logic required to plot various variables against mpg
shinyServer(function(input, output) {
  
})
