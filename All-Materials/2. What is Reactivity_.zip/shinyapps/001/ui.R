## 001 Live Example ui.R

library(shiny)

# Define UI for miles per gallon application
shinyUI(pageWithSidebar(
  
  # Application title
  headerPanel("Miles Per Gallon"),
  
  sidebarPanel(),
  
  mainPanel()
))
