## 002 ~/shinyapps Live Example mtcars server.R

library(shiny)

# Define server logic required to plot various variables against mpg
shinyServer(function(input, output) {
  
})
